export type Entity=number;
